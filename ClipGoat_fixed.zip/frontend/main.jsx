
import React, { useState } from "react";
import { createRoot } from "react-dom/client";

function App() {
  const [url, setUrl] = useState("");
  const [status, setStatus] = useState("");

  async function handleDownload() {
    setStatus("Processing...");
    const res = await fetch(import.meta.env.VITE_BACKEND_URL + "/api/download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });
    const data = await res.json();
    setStatus(JSON.stringify(data, null, 2));
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>ClipGoat</h1>
      <input value={url} onChange={e => setUrl(e.target.value)} placeholder="YouTube/Twitch URL" />
      <button onClick={handleDownload}>Download</button>
      <pre>{status}</pre>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
