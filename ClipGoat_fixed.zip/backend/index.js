
import express from "express";
import cors from "cors";
import ytdlp from "yt-dlp-exec";
import ffmpeg from "fluent-ffmpeg";
import fs from "fs";

const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/download", async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: "No URL provided" });
  if (!fs.existsSync("videos")) fs.mkdirSync("videos");
  const output = `videos/${Date.now()}.mp4`;
  await ytdlp(url, { output, format: "mp4" });
  res.json({ success: true, file: output });
});

app.post("/api/clip", async (req, res) => {
  const { input, start, duration } = req.body;
  if (!fs.existsSync("clips")) fs.mkdirSync("clips");
  const output = `clips/${Date.now()}.mp4`;
  ffmpeg(input)
    .setStartTime(start)
    .setDuration(duration)
    .output(output)
    .on("end", () => res.json({ success: true, output }))
    .on("error", err => res.status(500).json({ error: err.message }))
    .run();
});

app.listen(3000, () => console.log("Backend running on port 3000"));
